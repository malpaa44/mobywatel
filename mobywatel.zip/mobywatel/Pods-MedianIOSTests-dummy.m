#import <Foundation/Foundation.h>
@interface PodsDummy_Pods_MedianIOSTests : NSObject
@end
@implementation PodsDummy_Pods_MedianIOSTests
@end
