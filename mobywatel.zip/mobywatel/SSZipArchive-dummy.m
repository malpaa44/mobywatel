#import <Foundation/Foundation.h>
@interface PodsDummy_SSZipArchive : NSObject
@end
@implementation PodsDummy_SSZipArchive
@end
