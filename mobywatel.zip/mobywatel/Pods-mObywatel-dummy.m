#import <Foundation/Foundation.h>
@interface PodsDummy_Pods_mObywatel : NSObject
@end
@implementation PodsDummy_Pods_mObywatel
@end
