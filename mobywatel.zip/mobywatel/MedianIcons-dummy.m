#import <Foundation/Foundation.h>
@interface PodsDummy_MedianIcons : NSObject
@end
@implementation PodsDummy_MedianIcons
@end
